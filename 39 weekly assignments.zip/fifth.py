import psutil, os

process = psutil.Process(os.getpid())
print(f"Memory usage: {process.memory_info().rss} bytes")  

import time

start = time.perf_counter()  
def legendre_symbol(a, p):
    if a % p == 0:
        return 0

    exp = (p - 1) // 2
    result = 1
    base = a % p

    while exp > 0:
        if exp % 2 == 1:       
            result = (result * base) % p
        base = (base * base) % p
        exp = exp // 2

    if result == 1:
        return 1
    elif result == p - 1:
        return -1
    else:
        return 0   
    print(f"Legendre symbol ({a}/{p}) =", legendre_symbol(a, p))
n = int(input("Enter a positive integer a: "))
p = int(input("Enter a prime number p: "))
print(f"Legendre symbol ({n}/{p}) =", legendre_symbol(n, p))

end = time.perf_counter() 


print("Execution time:", end - start, "seconds")