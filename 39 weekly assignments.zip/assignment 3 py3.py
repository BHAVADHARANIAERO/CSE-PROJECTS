def is_automorphic(n):

    if n < 0:
        print("Enter positive number")

    square = n * n
  
  
    x = str(n)
    y = str(square)

  
    if y.endswith(x):
        return True
    else:
        return False
        

print(is_automorphic(1))
print(is_automorphic(12))
print(is_automorphic(6))
