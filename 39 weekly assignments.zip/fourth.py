import psutil, os

process = psutil.Process(os.getpid())
print(f"Memory usage: {process.memory_info().rss} bytes")  
import time

start = time.perf_counter()   
def prime_pi(n):
    count = 0
    num = 2   

    while num <= n:
        is_prime = 1   
        divisor = 2
        while divisor * divisor <= num:   
            if num % divisor == 0:
                is_prime = 0
                break
            divisor = divisor + 1
        if is_prime == 1:
            count = count + 1
        num = num + 1

    return count

n = int(input("Enter a positive integer: "))
print("Number of primes up to", n, "is", prime_pi(n))
end = time.perf_counter() 
print("Execution time:", end - start, "seconds")