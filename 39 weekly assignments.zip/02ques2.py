
def is_prime_power(n):
    
    if n < 2:
        raise ValueError("Input must be a positive integer greater than 1")
    
    max_exponent = n.bit_length()  
    for k in range(1, max_exponent + 1):
        
        root = round(n ** (1 / k))
        
    
        for candidate in [root - 1, root, root + 1]:
            if candidate < 2:
                continue
            power = candidate ** k
            if power == n and is_prime(candidate):
                return True
    
    return False

def is_prime(num):
    
    if num < 2:
        return False
    if num == 2:
        return True
    if num % 2 == 0:
        return False
    
    for i in range(3, int(num**0.5) + 1, 2):
        if num % i == 0:
            return False
    return True
print(is_prime_power(27)) 