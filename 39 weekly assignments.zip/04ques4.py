def twin_primes(limit):
    

    if limit < 3:
        raise ValueError("Limit must be at least 3")
    
    
    primes = sieve_of_eratosthenes(limit)
    
    
    twin_pairs = []
    for i in range(len(primes) - 1):
        if primes[i + 1] - primes[i] == 2:
            twin_pairs.append((primes[i], primes[i + 1]))
    
    return twin_pairs

def sieve_of_eratosthenes(n):
   
    if n < 2:
        return []
    
    sieve = [True] * (n + 1)
    sieve[0] = sieve[1] = False
    
    for i in range(2, int(n**0.5) + 1):
        if sieve[i]:
            sieve[i*i : n+1 : i] = [False] * len(sieve[i*i : n+1 : i])
    
    return [i for i, is_prime in enumerate(sieve) if is_prime]
print("Twin primes up to 20:")
print(twin_primes(20))