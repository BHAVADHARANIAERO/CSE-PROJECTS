def is_perfect_power(n):
    if n <= 0:
        return False
    if n == 1:
        return True
    
    max_a = int(n**0.5)
    
    for a in range(2, max_a + 1):
        if n % a == 0:
            power = a * a
            while power <= n:
                if power == n:
                    return True
                power = power * a
                
    return False


print(f"Is 8 a perfect power? {is_perfect_power(8)}")
