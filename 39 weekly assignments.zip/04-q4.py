def polygonal_number(s, n):
   
    if s < 3 or n < 1:
        return None  

    numerator = (s - 2) * (n ** 2) - (s - 4) * n
    
  
    return numerator // 2


print(f"The 5th 3-gonal (triangular) number is: {polygonal_number(3, 5)}")

