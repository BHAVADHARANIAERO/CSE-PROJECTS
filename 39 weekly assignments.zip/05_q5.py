def _is_prime(n):

    if n < 2:
        return False
    if n == 2 or n == 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

def _get_prime_factors(n):
   
    factors = set()
    
   
    if n % 2 == 0:
        factors.add(2)
        while n % 2 == 0:
            n //= 2
            
    
    i = 3
    while i * i <= n:
        if n % i == 0:
            factors.add(i)
            while n % i == 0:
                n //= i
        i += 2
        
  
    if n > 2:
        factors.add(n)
        
    return factors

def is_carmichael(n):
   
   
    if n < 2 or _is_prime(n):
        return False
        
    factors = _get_prime_factors(n)
    
   
    product_of_factors = 1
    for p in factors:
        product_of_factors *= p
        
    if product_of_factors != n:
        return False
        
    
    for p in factors:
        if (n - 1) % (p - 1) != 0:
            return False