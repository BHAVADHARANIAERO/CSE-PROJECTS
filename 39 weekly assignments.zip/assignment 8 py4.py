import time

def partitions(n):

    p = [0] * (n + 1)


   
    p[0] = 1

    for i in range(1, n + 1):
        k = 1
        while ((k * (3 * k - 1)) / 2 <= i) :
            p[i] += ((1 if k % 2 else -1) * 
                    p[i - (k * (3 * k - 1)) // 2])

            if (k > 0):
                k *= -1
            else:
                k = 1 - k

    return p[n]

st=time.perf_counter()
print(partitions(7))
print(partitions(20))
print(partitions(11))
et=time.perf_counter()
duration=et-st
print(f"duration:{duration:.6f}")

