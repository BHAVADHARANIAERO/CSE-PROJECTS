import math
import time


def count_divisors(num):
  
    if num <= 0:
        return 0
    divisor_count = 0
    for i in range(1, int(math.sqrt(num) + 1)):
        if num % i == 0:
            if num / i == i:  
                divisor_count += 1
            else:
                divisor_count += 2
    return divisor_count

def is_highly_composite(n):
  
    if n <= 0:
        return False
        
    original_divisor_count = count_divisors(n)
    
  
    for i in range(1, n):
        if count_divisors(i) >= original_divisor_count:
            return False 
            
    return True  


st=time.perf_counter()
print(is_highly_composite(1))
print(is_highly_composite(6))
print(is_highly_composite(7)) 
et=time.perf_counter()
duration=et-st
print(f"Execution time: {duration:.6f} seconds")

                        
