import time

def are_amicable(a,b):
     if a<0:
         return "enter a positive number"

     x=0
     for i in range (1,a//2+1):
         if a % i ==0:
             x+=i
         if x==b:
             return True

st=time.perf_counter()
print(are_amicable(84,20))
print(are_amicable(7,8))
print(are_amicable(220,284))
et=time.perf_counter()
duration=et-st
print("duration:",duration)
