def collatz_length(n):
    if n < 1:
        return 0

    steps = 0
    while n != 1:
        if n % 2 == 0:
            n = n // 2
        else:
            n = 3 * n + 1
        steps += 1
    
    return steps

start_num = 6
print(f"The Collatz sequence length for {start_num} is: {collatz_length(start_num)}")
