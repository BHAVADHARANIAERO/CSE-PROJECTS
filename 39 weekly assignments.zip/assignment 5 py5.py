import time

def mod_exp(base, exponent, modulus):
    
    if modulus == 1:
        return 0  

    result = 1
    base %= modulus  

    while exponent > 0:
        
        if exponent % 2 == 1:
            result = (result * base) % modulus

        
        base = (base * base) % modulus

       
        exponent //= 2
    

    return result



st=time.perf_counter()
base1 = 2
exponent1 = 3
modulus1 = 5
result1 = mod_exp(base1, exponent1, modulus1)
print(f"({base1}^{exponent1}) % {modulus1} = {result1}")
et=time.perf_counter()
duration=et-st
print(f"Execution time: {duration:.6f} seconds")

    
