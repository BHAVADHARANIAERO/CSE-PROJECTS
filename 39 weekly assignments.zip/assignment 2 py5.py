''' 5th program '''
import time
import tracemalloc

tracemalloc.start()
ST=time.time()

def  is_abundant(n):
     if n < 1:
        return False

     add = 0
    
     for i in range(1, n):
        if n % i == 0:
            add += i

     return add > n

print(is_abundant(12))  
print(is_abundant(17))  
print(is_abundant(13))

ET=time.time()
duration=ET-ST
current, peak = tracemalloc.get_traced_memory()
print(f" The total duration of the program is:{duration} seconds")
print(f" The total memory used is:{peak} bytes")
