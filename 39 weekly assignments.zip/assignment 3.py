import math

def is_deficient(n):
    
    if n <= 0:
        return False
        
    sum_of_divisors = 1  
    for i in range(2, int(math.sqrt(n)+1)):
        if n % i == 0:
            sum_of_divisors += i
            if i * i != n:
                sum_of_divisors += n // i
    
    return sum_of_divisors < n

        
          
print(is_deficient(6))
print(is_deficient(8))
print(is_deficient(95))
