import psutil, os

process = psutil.Process(os.getpid())
print(f"Memory usage: {process.memory_info().rss} bytes")  

import time

start = time.perf_counter()   

def euler_phi(n):
    if n <= 0:
        return 0
    if n == 1:
        return 1
    count = 0
    for k in range(1, n + 1):
        a,b = n, k
        while b:
            a, b = b, a % b
        if a == 1:
            count += 1
    return count
if __name__ == "__main__":
    n = int(input("Enter a positive integer: "))
    print("Euler's Totient function for", n, "is", euler_phi(n))

end = time.perf_counter() 


print("Execution time:", end - start, "seconds")