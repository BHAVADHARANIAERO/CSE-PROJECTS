


def count_distinct_prime_factors(n):
    if n < 2:
        raise ValueError
    
    count = 0
    temp = n
    

    if temp % 2 == 0:
        count += 1
        while temp % 2 == 0:
            temp //= 2
    

    factor = 3
    while factor * factor <= temp:
        if temp % factor == 0:
            count += 1
            while temp % factor == 0:
                temp //= factor
        factor += 2
    
    if temp > 1:
        count += 1
    
    return count
print(count_distinct_prime_factors(2310))    
