import time

def multiplicative_persistence(n):
    if n <10:
        return 0


    persistence=0
    number=n

    while number>=10:
        product=1
        for i in str(number):
            product *= int(i)
        number= product
        persistence += 1

    return persistence


st=time.perf_counter()
print(multiplicative_persistence(78))
print(multiplicative_persistence(888))
print(multiplicative_persistence(4))
et=time.perf_counter()
duration=et-st
print("duration:",duration)



