import time
st=time.perf_counter()
def aliquot_sum(n):

   
  if  n <= 0:
    return "enter a positive integer"
  
  x = 0
 
  for i in range(1, n // 2 + 1):
    if n % i == 0:
      x += i
      
  return x


st=time.perf_counter()
print(aliquot_sum(12)) 
print(aliquot_sum(6))  
print(aliquot_sum(1))   
et=time.perf_counter() 
execution_time =et-st
print("Execution time:",execution_time)
