def prime_factors(n):

    
    i = 2

    while i * i <= n:
      while n % i == 0:
        print(i)
        n //= i
      i += 1

    if n > 1:
        print(n)

      
print(prime_factors(35))
print(prime_factors(315))
print(prime_factors(6))
print(prime_factors(18))

 

