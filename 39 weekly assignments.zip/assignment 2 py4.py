''' 4th program'''

import time
import tracemalloc

tracemalloc.start()
ST=time.time()

def digital_root(n):
    if n < 0:
        raise ValueError("Input must be a non-negative integer.")

    while n >= 10:
        add = 0
        while n > 0:
            add += n % 10  
            n //= 10              
        n = add
    return n

print("The digital root is:",digital_root(1234))
print("The digital root is:",digital_root(3436))

ET=time.time()
duration=ET-ST
current, peak = tracemalloc.get_traced_memory()
print(f" The total duration of the program is:{duration} seconds")
print(f" The total memory used is:{peak} bytes")
