import time
def zeta_approx(s, terms):
    
    if terms <= 0:
        return 0.0

    zetasum = 0.0
    for n in range(1, terms + 1):
        zetasum += 1.0 / (n ** s)
    return zetasum
st=time.perf_counter()
s_value = 3
num_terms = 1000
approx_zeta = zeta_approx(s_value, num_terms)
print(approx_zeta)
et=time.perf_counter()
duration=et-st
print(f"duration:{duration:.6f}")
