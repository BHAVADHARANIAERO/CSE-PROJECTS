import psutil, os

process = psutil.Process(os.getpid())
print(f"Memory usage: {process.memory_info().rss} bytes")  
import time

start = time.perf_counter()  

def divisor_sum(n):
    total = 0
    i = 1
    while i <= n:
        if n % i == 0:  
            total = total + i
        i = i + 1
    return total


n = int(input("Enter a positive integer: "))
print("Sum of divisors of", n, "is", divisor_sum(n))

end = time.perf_counter() 


print("Execution time:", end - start, "seconds")