'''1st program'''

import time
import tracemalloc

tracemalloc.start()
ST=time.time()

def factorial(n):
    if n<0:
        print("Factorial is not defined for negative numbers")
    elif n==0:
        return 1
    else:
        value=1
        for i in range(1,n+1):
            value*=i
        return value


x=-2
result=factorial(x)
y=24
result1=factorial(y)
print (f" The factorial of {y} is {result1} ")

ET=time.time()
duration=ET-ST
current, peak = tracemalloc.get_traced_memory()
print(f" The total duration of the program is:{duration} seconds")
print(f" The total memory used is:{peak} bytes")




        

      
