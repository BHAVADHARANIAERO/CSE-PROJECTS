import psutil, os

process = psutil.Process(os.getpid())
print(f"Memory usage: {process.memory_info().rss} bytes")  

import time

start = time.perf_counter()  
def mobius(n):
    if n == 1:
        return 1

    factors = 0
    i = 2
    while i * i <= n:
        if n % i == 0:
            if (n // i) % i == 0:
                return 0
            factors += 1
            n = n // i
            while n % i == 0:
                n = n // i
        i += 1

    if n > 1:
        factors += 1

    if factors % 2 == 0:
        return 1
    else:
        return -1

n = int(input("Enter a positive integer: "))
print("Mobius function for", n, "is", mobius(n))

end = time.perf_counter() 


print("Execution time:", end - start, "seconds")