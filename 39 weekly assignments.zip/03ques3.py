
def is_mersenne_prime(p):

    if p < 2:
        raise ValueError("Input p must be at least 2")
    
    mersenne = 2**p - 1
    
    known_mersenne_primes = {2, 3, 5, 7, 13, 17, 19, 31, 61, 89, 107, 127}
    if p in known_mersenne_primes:
        return True
    
    return is_prime_mersenne(mersenne)

def is_prime_mersenne(n):
   
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    
    limit = int(n**0.5) + 1
    
    k = 1
    divisor = 2 * k * (n.bit_length()) + 1  
    
    while divisor <= limit:
        if n % divisor == 0:
            return False
        k += 1
        divisor = 2 * k * (n.bit_length()) + 1
    
    return True
print(is_mersenne_prime(7))