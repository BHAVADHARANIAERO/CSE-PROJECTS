''' 2nd program '''
import time
import tracemalloc

tracemalloc.start()
ST=time.time()


def is_palindrome(num):

    if num<0:
        return False
    elif num==0:
        return True

    original=num
    reverse=0

    while num>0:
        digit=num%10
        reverse=reverse*10+digit
        num //=10
        if original==reverse:
            return True
         

    

print(f"121 is a palindrome: {is_palindrome(121)}")
print(f"123 is a palindrome: {is_palindrome(123)}")
print(f"-121 is a palindrome: {is_palindrome(-121)}")
print(f"0 is a palindrome: {is_palindrome(0)}")

ET=time.time()
duration=ET-ST
current, peak = tracemalloc.get_traced_memory()
print(f" The total duration of the program is:{duration} seconds")
print(f" The total memory used is:{peak} bytes")

