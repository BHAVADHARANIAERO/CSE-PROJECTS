def lucas_sequence(n):
   
    if n <= 0:
        return  
    a, b = 2, 1

   
    if n >= 1:
        yield a
    
    
    if n >= 2:
        yield b

    
    for _ in range(2, n):
        c = a + b
        yield c
        a, b = b, c

n_terms = 10
lucas_gen = lucas_sequence(n_terms)

print(f"The first {n_terms} Lucas numbers are:")

print(list(lucas_gen))


