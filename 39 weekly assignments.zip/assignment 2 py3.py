'''3rd program'''
import time
import tracemalloc

tracemalloc.start()
ST=time.time()

def mean_of_digits(n):
    digiSum, digiLen = 0, 0

    while n:
        digiLen += 1
        digiSum += n % 10
        n = n//10
    return(digiSum/digiLen)

print (" The average of digits is:",mean_of_digits(567))
print (" The average of digits is:",mean_of_digits(76547))

ET=time.time()
duration=ET-ST
current, peak = tracemalloc.get_traced_memory()
print(f" The total duration of the program is:{duration} seconds")
print(f" The total memory used is:{peak} bytes")
    
     
     
