def is_harshad(n):
  
  if n <= 0:  
    return False

  sum_of_digits = 0
  x = n
  while x > 0:
    sum_of_digits += x % 10  
    x //= 10  

 
  return n % sum_of_digits==0


print(is_harshad(12))
print(is_harshad(15))

