def count_divisors(n):
    if n <= 0:
        raise ValueError("Input must be a positive integer")
    
    if n == 1:
        return 1
    
    count = 1  
    i = 2
    while i * i <= n:
        if n % i == 0:

            if i * i == n:
                count += 1  
            else:
                count += 2  
        i += 1
    
    return count + 1
print(f"d(12) = {count_divisors(12)}") 