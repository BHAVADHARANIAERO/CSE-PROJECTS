import math

def is_pronic(n):
   
    
    if n < 0:
        return False  
    
    
    for i in range(0,n): 
        if i * (i + 1) == n:
            return True
    else:
        return False

print(is_pronic(6))
print(is_pronic(4))
print(is_pronic(42))
print(is_pronic(30))
        

            





    
